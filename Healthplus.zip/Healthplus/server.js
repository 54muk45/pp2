const express = require('express');
const path = require('path');
const app = express();

// Configuração
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));

// Rotas principais
app.get('/', (req, res) => {
  res.render('index');
});

app.get('/login', (req, res) => {
  res.render('login');
});

app.get('/criar-conta', (req, res) => {
  res.render('criar-conta');
});

app.get('/categorias', (req, res) => {
  res.render('categorias');
});

app.get('/entregas', (req, res) => {
  res.render('entregas');
});

// Porta
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
