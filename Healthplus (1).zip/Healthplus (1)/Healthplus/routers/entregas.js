const express = require('express');
const router = express.Router();

router.get('/entregas', (req, res) => {
    res.render('entregas'); // Certifique-se que existe o arquivo views/criar-conta.ejs
});

module.exports = router;
;
