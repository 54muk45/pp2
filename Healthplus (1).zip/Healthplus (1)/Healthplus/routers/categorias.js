const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
    res.render('categorias'); // Certifique-se que existe o arquivo views/categorias.ejs
});

module.exports = router;
