const express = require('express');
const path = require('path');

const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));


app.use(express.static(path.join(__dirname, 'public')));


const Produto = require('./models/Produto');


app.get('/', (req, res) => {
    res.render('index');
});

app.get('/produtos', async (req, res) => {
    const produtos = await Produto.find();
    res.render('produtos', { produtos });
});
// Importar as rotas
const categoriasRoutes = require('./routes/categorias');
const contaRoutes = require('./routes/conta');

// Usar as rotas
app.use('/categorias', categoriasRoutes);
app.use('/', entregasRoutes); // /criar-conta estará disponível

// Start servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`🚀 Servidor rodando na porta ${PORT}`);
});
